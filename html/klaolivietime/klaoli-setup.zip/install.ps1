﻿# klaoli installer (self-built TSF frontend)
#
# Two modes (auto-detected):
#   - dist package: run from a directory with bin/ + data/ (built by tools/build_dist.py).
#       Deploys program files to %ProgramFiles%\klaoli.viet AND user data (runtime + rime)
#       to %APPDATA%\klaoli.viet.
#   - dev: run from installer/, reads program files from ../frontend/build; user data
#       is assumed to already live in %APPDATA%\klaoli.
#
# Then writes HKLM TSF registration + HKCU config and enables the language profile.
# Requires administrator (HKLM writes).
#
# Usage:  right-click -> Run with PowerShell
#         install.ps1 [-Source DIR]    # dev mode: DIR = dir with loader/impl/daemon/register_tip
#
param(
    [string]$Source = "",
    [string]$InstallDir = ""
)

$ErrorActionPreference = "Continue"

# --- self-elevate ---
$id = [Security.Principal.WindowsIdentity]::GetCurrent()
$pr = New-Object Security.Principal.WindowsPrincipal($id)
if (-not $pr.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "Requesting administrator privileges..." -ForegroundColor Yellow
    $arg = "-NoProfile -File `"$PSCommandPath`""
    if ($Source) { $arg += " -Source `"$Source`"" }
    if ($InstallDir) { $arg += " -InstallDir `"$InstallDir`"" }
    Start-Process powershell -Verb RunAs -ArgumentList $arg
    exit
}

# --- constants (keep in sync with frontend/src/tsf_defs.h) ---
$clsid       = "{2600F1F7-3B90-4153-B39C-3121992ED3BE}"
$profile     = "{ED6C16CC-7CC1-44E9-9623-5D8FC480ECA6}"
$catKeyboard = "{34745C63-B2F0-4784-8B67-5E12C8701A31}"
$langId      = "0x0000042A"
$desc        = "klaoli.viet"

$appDir  = if ($InstallDir) { $InstallDir } else { Join-Path $env:ProgramFiles "klaoli.viet" }
$dataDir = Join-Path $env:APPDATA "klaoli.viet"

function Set-RegValue($hive, $path, $name, $value, $kind) {
    $k = [Microsoft.Win32.Registry]::$hive.CreateSubKey($path)
    if ($null -eq $kind) { $k.SetValue($name, $value) }
    else { $k.SetValue($name, $value, $kind) }
    $k.Close()
}

# --- source detection ---
$distBin  = Join-Path $PSScriptRoot "bin"
$distData = Join-Path $PSScriptRoot "data"
$isDist = (Test-Path $distBin) -and (Test-Path $distData)

if ($isDist) {
    $binSrc  = $distBin
    $dataSrc = $distData
    Write-Host "mode: dist package"
} else {
    if (-not $Source) { $Source = Join-Path $PSScriptRoot "..\frontend\build" }
    $binSrc  = $Source
    $dataSrc = $null
    Write-Host "mode: dev (program files from $binSrc)"
}

if (-not (Test-Path (Join-Path $binSrc "klaoli_tsf_loader.dll"))) {
    Write-Host "!! loader dll not found in $binSrc" -ForegroundColor Red
    exit 1
}

# --- stop daemon（叠加安装时 daemon.exe 可能被占用，先停掉才能覆盖） ---
Write-Host "=== stop daemon ==="
Get-Process -Name "klaoli_daemon" -ErrorAction SilentlyContinue | ForEach-Object {
    Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
}
Start-Sleep -Milliseconds 500

# --- deploy program files ---
Write-Host "=== deploy program files -> $appDir ==="
New-Item -ItemType Directory -Force -Path $appDir | Out-Null
foreach ($f in @("klaoli_tsf_loader.dll", "klaoli_tsf.dll", "klaoli_daemon.exe", "register_tip.exe", "klaoli-uninst.exe")) {
    $s = Join-Path $binSrc $f
    if (Test-Path $s) {
        Copy-Item $s (Join-Path $appDir $f) -Force
        Write-Host "  $f"
    } else {
        Write-Host "  !! missing $f in source" -ForegroundColor Yellow
    }
}
$icoSrc = $null
if ($isDist) { $icoSrc = Join-Path $dataSrc "klaoli.ico" }
else { $icoSrc = Join-Path $PSScriptRoot "klaoli.ico"; if (-not (Test-Path $icoSrc)) { $icoSrc = Join-Path $PSScriptRoot "..\brand\klaoli.ico" } }
if ($icoSrc -and (Test-Path $icoSrc)) {
    Copy-Item $icoSrc (Join-Path $appDir "klaoli.ico") -Force
    Write-Host "  klaoli.ico"
}

# --- deploy user data (dist mode only) ---
if ($isDist) {
    Write-Host "=== deploy user data -> $dataDir ==="
    New-Item -ItemType Directory -Force -Path $dataDir | Out-Null

    # runtime：完整覆盖（自编译 rime.dll + 共享 data + 音节表）
    $rtSrc = Join-Path $dataSrc "runtime"
    if (Test-Path $rtSrc) {
        New-Item -ItemType Directory -Force -Path (Join-Path $dataDir "runtime") | Out-Null
        robocopy $rtSrc (Join-Path $dataDir "runtime") /E /IS /IT /NFL /NDL /NJH /NJS | Out-Null
        Write-Host "  runtime/ (完整覆盖)"
    }

    # rime：覆盖 schema/词典/lua，保留 *.userdb（用户词典）
    $rimeSrc = Join-Path $dataSrc "rime"
    if (Test-Path $rimeSrc) {
        New-Item -ItemType Directory -Force -Path (Join-Path $dataDir "rime") | Out-Null
        Get-ChildItem -LiteralPath $rimeSrc | ForEach-Object {
            if ($_.Name -like "*.userdb") { return }   # 保留目标机已有用户词典
            Copy-Item $_.FullName (Join-Path $dataDir "rime") -Recurse -Force
        }
        Write-Host "  rime/ (覆盖，保留 *.userdb)"
    }
}

# --- registry: HKLM CLSID -> loader dll ---
Write-Host "=== registry: HKLM CLSID -> loader dll ==="
Set-RegValue "LocalMachine" "SOFTWARE\Classes\CLSID\$clsid" $null $desc $null
Set-RegValue "LocalMachine" "SOFTWARE\Classes\CLSID\$clsid\InprocServer32" $null (Join-Path $appDir "klaoli_tsf_loader.dll") $null
Set-RegValue "LocalMachine" "SOFTWARE\Classes\CLSID\$clsid\InprocServer32" "ThreadingModel" "Apartment" $null

# --- registry: HKLM CTF\TIP ---
Write-Host "=== registry: HKLM CTF\TIP ==="
foreach ($tipRoot in @("SOFTWARE\Microsoft\CTF\TIP", "SOFTWARE\WOW6432Node\Microsoft\CTF\TIP")) {
    [Microsoft.Win32.Registry]::LocalMachine.CreateSubKey("$tipRoot\$clsid\Category\Category\$catKeyboard\$clsid") | Out-Null
    [Microsoft.Win32.Registry]::LocalMachine.CreateSubKey("$tipRoot\$clsid\Category\Item\$clsid\$catKeyboard") | Out-Null
    $lp = "$tipRoot\$clsid\LanguageProfile\$langId\$profile"
    Set-RegValue "LocalMachine" $lp "Description" $desc $null
    Set-RegValue "LocalMachine" $lp "IconFile"   (Join-Path $appDir "klaoli.ico") $null
    Set-RegValue "LocalMachine" $lp "IconIndex"  0 ([Microsoft.Win32.RegistryValueKind]::DWord)
    Set-RegValue "LocalMachine" $lp "Enable"     1 ([Microsoft.Win32.RegistryValueKind]::DWord)
}

# --- registry: HKCU frontend config ---
Write-Host "=== registry: HKCU frontend config ==="
# klaoli.viet display/dir name; CONFIG KEY STAYS ON THE OLD NAME ON PURPOSE:
# the packaged klaoli_tsf_loader.dll hardcodes Software\klaoli\frontend.
# Renaming this key would make fresh installs unable to load the impl dll.
$cfgKey = "Software\klaoli\frontend"
Set-RegValue "CurrentUser" $cfgKey "ImplDll"    (Join-Path $appDir "klaoli_tsf.dll") $null
Set-RegValue "CurrentUser" $cfgKey "DaemonPath" (Join-Path $appDir "klaoli_daemon.exe") $null
Set-RegValue "CurrentUser" $cfgKey "WeaselDir"  (Join-Path $dataDir "runtime") $null
Set-RegValue "CurrentUser" $cfgKey "UserDir"    (Join-Path $dataDir "rime") $null
try { [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($cfgKey, $true).DeleteValue("PluginDll", $false) } catch {}

# --- registry: HKLM Uninstall（控制面板「程序和功能」卸载项） ---
Write-Host "=== registry: HKLM Uninstall ==="
$unKey = "SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\klaoli.viet"
Set-RegValue "LocalMachine" $unKey "DisplayName"     "klaoli.viet" $null
Set-RegValue "LocalMachine" $unKey "DisplayIcon"     (Join-Path $appDir "klaoli.ico") $null
Set-RegValue "LocalMachine" $unKey "UninstallString" (Join-Path $appDir "klaoli-uninst.exe") $null
Set-RegValue "LocalMachine" $unKey "DisplayVersion"  "1.0.0" $null
Set-RegValue "LocalMachine" $unKey "Publisher"       "klaoli" $null
Set-RegValue "LocalMachine" $unKey "InstallLocation" $appDir $null
Set-RegValue "LocalMachine" $unKey "NoModify" 1 ([Microsoft.Win32.RegistryValueKind]::DWord)
Set-RegValue "LocalMachine" $unKey "NoRepair" 1 ([Microsoft.Win32.RegistryValueKind]::DWord)

# --- enable language profile ---
Write-Host "=== enable language profile ==="
$regTip = Join-Path $appDir "register_tip.exe"
if (Test-Path $regTip) {
    & $regTip
} else {
    Write-Host "!! register_tip.exe not found; language profile NOT enabled" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Done. Switch to 'klaoli.viet' in any app to type." -ForegroundColor Green
Write-Host "If the keyboard icon is stale, log off/on once."
