﻿# klaoli uninstaller (self-built TSF frontend)
#
# Unregisters the TSF language profile, deletes HKLM CLSID + CTF\TIP + HKCU config,
# stops the daemon, and removes program files under %ProgramFiles%\klaoli.viet.
# User data (%APPDATA%\klaoli.viet, contains dictionaries + user history) is KEPT by
# default; delete it manually if you want a full wipe.
#
# Usage:  right-click -> Run with PowerShell
#
$ErrorActionPreference = "Continue"

# --- self-elevate ---
$id = [Security.Principal.WindowsIdentity]::GetCurrent()
$pr = New-Object Security.Principal.WindowsPrincipal($id)
if (-not $pr.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "Requesting administrator privileges..." -ForegroundColor Yellow
    Start-Process powershell -Verb RunAs -ArgumentList "-NoProfile -File `"$PSCommandPath`""
    exit
}

$clsid   = "{2600F1F7-3B90-4153-B39C-3121992ED3BE}"
# 优先读注册表记录的安装目录（支持自定义目录），回退默认
$appDir = $null
try {
    $k = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\klaoli.viet")
    if ($k) { $appDir = $k.GetValue("InstallLocation"); $k.Close() }
} catch {}
if (-not $appDir) { $appDir = Join-Path $env:ProgramFiles "klaoli.viet" }

# --- stop daemon (its exe would be locked while running) ---
Write-Host "=== stop daemon ==="
Get-Process -Name "klaoli_daemon" -ErrorAction SilentlyContinue | ForEach-Object {
    Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
}
Start-Sleep -Milliseconds 500

# --- unregister language profile (per-user, via ITfInputProcessorProfiles) ---
Write-Host "=== unregister language profile ==="
$regTip = Join-Path $appDir "register_tip.exe"
if (Test-Path $regTip) { & $regTip /u }

# --- delete HKLM CLSID + CTF\TIP ---
Write-Host "=== delete HKLM registration ==="
foreach ($key in @(
        "SOFTWARE\Classes\CLSID\$clsid",
        "SOFTWARE\Microsoft\CTF\TIP\$clsid",
        "SOFTWARE\WOW6432Node\Microsoft\CTF\TIP\$clsid",
        "SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\klaoli.viet",
        "SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\klaoli.viet"
    )) {
    try { [Microsoft.Win32.Registry]::LocalMachine.DeleteSubKeyTree($key, $false); Write-Host "  removed $key" }
    catch { Write-Host "  (skip) $key" }
}

# --- delete HKCU frontend config ---
Write-Host "=== delete HKCU config ==="
try { [Microsoft.Win32.Registry]::CurrentUser.DeleteSubKeyTree("Software\klaoli\frontend", $false); Write-Host "  removed HKCU Software\klaoli\frontend" }
catch { Write-Host "  (skip) HKCU config" }

# --- remove program files ---
Write-Host "=== remove program files ==="
if (Test-Path $appDir) {
    Remove-Item -Path $appDir -Recurse -Force -ErrorAction SilentlyContinue
    if (Test-Path $appDir) { Write-Host "  !! could not remove $appDir (files still locked?)" -ForegroundColor Yellow }
    else { Write-Host "  removed $appDir" }
}

Write-Host ""
Write-Host "Uninstall done." -ForegroundColor Green
Write-Host "User data kept at: $env:APPDATA\klaoli.viet (dictionaries + user history)."
Write-Host "Delete that folder manually if you want a full wipe."
