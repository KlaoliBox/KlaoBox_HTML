-- lead_space.lua  (UTF-8, no BOM)
-- 前导空格判定状态机（2026-09-06 取代 commit_history 判句首）
--
-- 旧方案不稳定根源：commit_history 只记录"经引擎上屏"的文本，
-- 但空编码下手动按 空格/回车/退格/方向键 直接透传给应用，引擎根本看不到，
-- 导致状态失真（典型：手动空格后打词 → 双空格；换行后打词 → 行首多空格）。
--
-- 新方案：维护"应用侧光标前一个字符"镜像 M.last，双通道更新：
--   1) commit_notifier：任何经引擎的上屏（候选/标点/raw）→ 取上屏文本末字符
--   2) processor：空编码下观察透传键 → 更新
--      - Space      → " "（下一个词不加前导空格，根治双空格）
--      - Return/Tab → "\n"（句首/新单元格）
--      - Backspace/Delete/方向键/Home/End/PgUp/PgDn → ""（未知，保守不加）
--      - 数字等可打印非字母键 → 该字符（透传给应用）
--      - 字母键不更新（字母进入编码，上屏走 commit_notifier）
--
-- need_space() 规则（越南语空格习惯）：
--   行首/空白后/未知状态/开括号 ( [ { « 之后 → 不加；其余（词、标点、闭引号后）→ 加

local KC = {
  space = 0x20, ret = 0xFF0D, tab = 0xFF09,
  backspace = 0xFF08, delete = 0xFFFF,
  home = 0xFF50, end_ = 0xFF57, pgup = 0xFF55, pgdn = 0xFF56,
  left = 0xFF51, right = 0xFF53, up = 0xFF52, down = 0xFF54,
}

-- 打开型括号/引号后不加空格（越南语：闭括号后加，开括号后不加）
local NO_SPACE_AFTER = { ["("]=true, ["["]=true, ["{"]=true, ["«"]=true }

local M = { last = "\n" }  -- "\n"=行首（默认保守），""=未知

local function last_char(s)
  if not s or s == "" then return "" end
  local p = #s
  while p > 1 and s:byte(p) >= 0x80 and s:byte(p) <= 0xBF do p = p - 1 end
  return s:sub(p)
end

function M.init(env)
  -- 上屏通道：候选、标点、raw 上屏都走这里（含点击候选窗上屏）
  env.engine.context.commit_notifier:connect(function(ctx)
    M.last = last_char(ctx:get_commit_text())
  end)
end

function M.func(key, env)
  local ctx = env.engine.context
  if key:release() or ctx:is_composing() then
    return 2  -- kNoop：编码中的键由引擎处理，上屏走 commit_notifier
  end
  local kc = key.keycode
  if kc == KC.space then
    M.last = " "
  elseif kc == KC.ret or kc == KC.tab then
    M.last = "\n"
  elseif kc == KC.backspace or kc == KC.delete or kc == KC.home
      or kc == KC.end_ or kc == KC.pgup or kc == KC.pgdn
      or kc == KC.left or kc == KC.right or kc == KC.up or kc == KC.down then
    M.last = ""   -- 光标移动/删除：应用侧状态未知，保守不加空格
  else
    -- 空编码下的可打印非字母键（数字等）会透传给应用
    -- （标点由 punctuator 经引擎上屏，走 commit_notifier，无需在此处理）
    local ch = key:repr()
    if #ch == 1 and ch:match("[%d%p]") then
      M.last = ch
    end
  end
  return 2  -- kNoop
end

function M.need_space()
  local c = M.last
  if c == "" or c == " " or c == "\n" or c == "\t" then return "" end
  if NO_SPACE_AFTER[c] then return "" end
  return " "
end

return M
