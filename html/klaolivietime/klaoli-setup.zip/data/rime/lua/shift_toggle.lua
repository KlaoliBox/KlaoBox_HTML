-- shift_toggle.lua  (UTF-8, no BOM)
-- 单次按下 Shift 切换 汉字/国语字 模式（toggle，非长按）
-- 区分「单独按 Shift」和「Shift+组合键」：只有单独按 Shift 才切换
-- 由 lua_processor@shift_toggle 调用；返回值 1=kAccepted / 其他=kNoop

local SHIFT_L = 0xffe1  -- XK_Shift_L
local SHIFT_R = 0xffe2  -- XK_Shift_R

local shift_pressed = false  -- Shift 是否处于按下状态
local shift_alone = true     -- Shift 按下期间是否只按了 Shift（无组合键）

local function process(key_event, env)
  local ctx = env.engine.context
  local kc = key_event.keycode
  local is_shift = (kc == SHIFT_L or kc == SHIFT_R)

  if is_shift then
    if key_event:release() then
      -- Shift 松开：若期间只按了 Shift（无组合键），才 toggle 模式
      if shift_pressed and shift_alone then
        ctx:set_option("hanzi_mode", not ctx:get_option("hanzi_mode"))
      end
      shift_pressed = false
    else
      -- Shift 按下：标记开始，默认是「单独按」
      shift_pressed = true
      shift_alone = true
    end
    return 1  -- kAccepted，消费 Shift 键
  end

  -- 非 Shift 键：若 Shift 正按着，说明是组合键（如 Shift+Tab），取消「单独按」
  if shift_pressed then
    shift_alone = false
  end
  return 2  -- kNoop，放行其他键
end

return process
