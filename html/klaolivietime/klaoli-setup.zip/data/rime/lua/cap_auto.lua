-- cap_auto.lua  (UTF-8, no BOM)
-- 自动大写：Shift+字母 输入大写时，转小写注入并设 cap_auto 标记，
-- filter 层据此对国语字候选做首字母大写（cap_mode 的自动版，两者并行互补）。
--
-- cap_mode（Control+Tab）：持续状态，适合连续打多个专名
-- cap_auto（Shift+首字母）：当前输入串临时标记，上屏即失效，适合偶发单个专名

local function processor(key, env)
  local ctx = env.engine.context
  -- 忽略释放键、Alt/Ctrl 组合键
  if key:release() or key:alt() or key:ctrl() then
    return 2  -- kNoop
  end
  local ch = key:repr()
  if ch and ch:match("^[A-Z]$") then
    -- 大写字母：仅词首（当前输入为空）时设 cap_auto 标记
    if (ctx.input or "") == "" then
      ctx:set_option("cap_auto", true)
    end
    -- 转小写注入，让 speller 能正常匹配词典
    ctx:push_input(ch:lower())
    return 1  -- kAccepted：消费掉这个大写 key
  elseif ch and ch:match("^[a-z]$") then
    -- 小写字母：词首（输入为空）时重置 cap_auto（新词默认小写）
    if (ctx.input or "") == "" then
      ctx:set_option("cap_auto", false)
    end
  end
  return 2  -- kNoop
end

return processor
