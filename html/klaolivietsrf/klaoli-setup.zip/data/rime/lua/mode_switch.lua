-- mode_switch.lua  (UTF-8, no BOM)
-- 1) hanzi_mode: 汉字模式显示汉字 + 国语字(拉丁,降权)；国语字模式只显示拉丁
-- 2) cap_mode  : 国语字模式下，每音节首字母大写（越南语专名式）
-- 3) 汉字模式下，按「候选字词 + 输入码」精确匹配注入带调越南语注释
-- 4) qn_mode  : 是否放出第 4 本「去重的国语字词典」的独立候选（只有模式三开）
--
-- options:
--   hv_comment -> 汉字候选是否挂国语字注释（设置窗口开关）
--   qn_mode    -> 第 4 本候选（前端按大模式 big_mode==3 下发，见 text_service.cc）
--   （hanzi_mode 由前端 SetOption 直接切，不走 key_binder）

-- 带调注释映射：text -> { code -> toned Vietnamese }
local COMMENTS = require("comment_map")
-- 第 4 本（hanviet_words_qn，去重的国语字词典）的全部词形，由 gen_qn_dict.py
-- 生成。用来判断候选是否来自第 4 本 —— Rime 的 translator 不能按 option 开关，
-- 而 script_translator 又不把词典注释(comment)暴露给 lua（实测读不到），
-- 所以只能按词形认。第 4 本已按词形对 native 去重，故不会误杀 native 的候选。
local QN_WORDS = require("qn_words")
-- 喃字单字集合（hanviet_chars_nom），由 gen_nom_chars_lua.py 生成。
-- 用来判断候选词形里是否含喃字：非「纯汉喃」大模式（hannom_mode=false）时
-- 把含喃字的候选（单字/单字组合/词组）过滤掉，只有大模式 4 才放行。
-- 用单字集合而非词组词形集合：script_translator 单字词典会对多音节输入做
-- 单字组合（"an com" -> 咹膁），组合词形不在任何词典里，词组集合认不到。
local NOM_CHARS = require("nom_chars")
-- 喃字系词典全部词形集合（tools/gen_nom_words_lua.py）。与单字集合互补：
-- 单字集合抓单字/单字组合，词形集合抓「纯汉字词形」的汉喃词条
-- （如 hannom 数据源的 陰曆/廕呃 —— 字形不在 nom 单字表，逐字判不出）。
local NOM_WORDS = require("nom_words")
-- 繁体词形 -> 简体（gen_trad_dicts.py）。comment_map 的键是简体。
local TRAD_MAP = require("trad_map")
-- 繁体词典条目文本尾 ZWSP（U+200B），用来认来源。简繁同形（台）也靠它区分。
local ZWSP = "\226\128\139"  -- U+200B UTF-8（兼容 lua 5.1）
-- 前导空格判定状态机（2026-09-06：取代 commit_history，见 lead_space.lua）
local lead = require("lead_space")

-- AUTO-GENERATED: Vietnamese lower->upper map (89 pairs)
local UPPER = {
  ["a"]="A", ["b"]="B", ["c"]="C", ["d"]="D", ["e"]="E", ["g"]="G",
  ["h"]="H", ["i"]="I", ["k"]="K", ["l"]="L", ["m"]="M", ["n"]="N",
  ["o"]="O", ["p"]="P", ["q"]="Q", ["r"]="R", ["s"]="S", ["t"]="T",
  ["u"]="U", ["v"]="V", ["x"]="X", ["y"]="Y", ["à"]="À", ["á"]="Á",
  ["â"]="Â", ["ã"]="Ã", ["è"]="È", ["é"]="É", ["ê"]="Ê", ["ì"]="Ì",
  ["í"]="Í", ["ò"]="Ò", ["ó"]="Ó", ["ô"]="Ô", ["õ"]="Õ", ["ù"]="Ù",
  ["ú"]="Ú", ["ý"]="Ý", ["ă"]="Ă", ["đ"]="Đ", ["ĩ"]="Ĩ", ["ũ"]="Ũ",
  ["ơ"]="Ơ", ["ư"]="Ư", ["ạ"]="Ạ", ["ả"]="Ả", ["ấ"]="Ấ", ["ầ"]="Ầ",
  ["ẩ"]="Ẩ", ["ẫ"]="Ẫ", ["ậ"]="Ậ", ["ắ"]="Ắ", ["ằ"]="Ằ", ["ẳ"]="Ẳ",
  ["ẵ"]="Ẵ", ["ặ"]="Ặ", ["ẹ"]="Ẹ", ["ẻ"]="Ẻ", ["ẽ"]="Ẽ", ["ế"]="Ế",
  ["ề"]="Ề", ["ể"]="Ể", ["ễ"]="Ễ", ["ệ"]="Ệ", ["ỉ"]="Ỉ", ["ị"]="Ị",
  ["ọ"]="Ọ", ["ỏ"]="Ỏ", ["ố"]="Ố", ["ồ"]="Ồ", ["ổ"]="Ổ", ["ỗ"]="Ỗ",
  ["ộ"]="Ộ", ["ớ"]="Ớ", ["ờ"]="Ờ", ["ở"]="Ở", ["ỡ"]="Ỡ", ["ợ"]="Ợ",
  ["ụ"]="Ụ", ["ủ"]="Ủ", ["ứ"]="Ứ", ["ừ"]="Ừ", ["ử"]="Ử", ["ữ"]="Ữ",
  ["ự"]="Ự", ["ỳ"]="Ỳ", ["ỵ"]="Ỵ", ["ỷ"]="Ỷ", ["ỹ"]="Ỹ",
}

local function first_char(s)
  -- first UTF-8 character of a string
  return s:match("^[\1-\127\194-\244][\128-\191]*")
end

local function cap_syllables(text)
  local tail = text:match("%s+$") or ""  -- 保留原尾空格（如 "việt nam " -> " "）
  local out = {}
  for syl in text:gmatch("%S+") do
    local ch = first_char(syl)
    if ch then
      local up = UPPER[ch]
      if up then
        syl = up .. syl:sub(#ch + 1)
      end
    end
    out[#out + 1] = syl
  end
  return table.concat(out, " ") .. tail
end

local function looks_han(text)
  -- CJK (U+4E00-U+9FFF) starts with 0xE4-0xE9; extensions start with 0xF0
  return text:find("[\227-\233\240]") ~= nil
end

local function has_quoc_ngu(text)
  -- 词形里含 ASCII 字母或越南语带调字符（首字节 0xC3/0xC4/0xC5/0xC6/0xE1）。
  -- 纯汉喃模式用：含拉丁的候选（native / qn / hanqn 混合）一律过滤，
  -- 只留纯 CJK（汉字 + 喃字）。
  return text:find("[A-Za-z]") ~= nil
      or text:find("[\195\196\197\198\225]") ~= nil
end

local function has_nom_char(text)
  -- 候选词形里是否含喃字（逐 UTF-8 字符查 NOM_CHARS 单字集合）。
  for ch in text:gmatch("[\1-\127\194-\244][\128-\191]*") do
    if NOM_CHARS[ch] then
      return true
    end
  end
  return false
end

local function is_word(text)
  -- 词 = 汉字或拉丁字母开头；标点/符号 = 非词
  local ch = first_char(text)
  if not ch then return false end
  if ch:find("[\227-\233\240]") then return true end    -- 汉字
  if ch:find("[\65-\90\97-\122]") then return true end  -- A-Z a-z
  if ch:find("[\195]") then return true end             -- 越南语带调字符(0xC3 起)
  return false
end

local function filter(input, env)
  local ctx = env.engine.context
  local hanzi = ctx:get_option("hanzi_mode")
  local cap = ctx:get_option("cap_mode")
  local cap_auto = ctx:get_option("cap_auto")
  -- 汉越词候选后面是否挂国语字注释（设置窗口的开关，默认开）。
  -- 未声明过的 option 取到 false，所以 schema 的 switches 里必须 reset: 1。
  local hv_comment = ctx:get_option("hv_comment")
  -- 模式三：是否放出第 4 本（去重的国语字词典）的独立候选，默认关。
  -- 同样必须在 schema 的 switches 里声明，否则这里恒为 false。
  local qn_mode = ctx:get_option("qn_mode")
  -- 繁体汉字（设置窗口开关）。未声明则 false = 简体。
  local trad_mode = ctx:get_option("trad_mode")
  -- 纯汉喃字大模式（前端按 big_mode==4 下发）。为 true 时只显示纯汉字/喃字候选。
  local hannom_mode = ctx:get_option("hannom_mode")
  local input_str = (ctx.input or ""):gsub("%s+", "")
  -- 当前输入的有效长度（字节）。候选的 end 若超过它，说明候选覆盖范围越界
  -- （典型：用户词典短语编码带空格如 "trung quoc" 长度 10，而无空格输入
  --  "trungquoc" 只有 9 字节），选择这种候选会进组字区等待回车、不直接上屏。
  local input_len = #(ctx.input or "")
  -- 前导空格：非句首（应用侧光标前一个字符是词/标点）时，词候选前面补一个空格
  -- 越南语规则：词间空格、标点前无空格、标点后空格
  -- 由 lead_space.lua 状态机判定（commit_notifier + 透传键跟踪）
  local leading = lead.need_space()
  for cand in input:iter() do
    local text = cand.text
    -- end 越界 → 直接丢弃（否则选中后进 preedit，见 input_len 注释）
    local end_overflow = (cand._end ~= nil and cand._end > input_len)
    local from_trad = (text:find(ZWSP, 1, true) ~= nil)
    if from_trad then
      text = text:gsub(ZWSP, "")
    end
    -- 第 4 本的候选：只有模式三放出，其余模式直接丢掉（见 QN_WORDS 注释）
    local from_qn = (QN_WORDS[text] == true)
    -- 候选词形是否来自喃字系词典（单字/单字组合/词组/纯汉字词形全覆盖）：
    -- 含喃字（单字集合）OR 词形在喃字词典词形集合
    local from_nom = has_nom_char(text) or (NOM_WORDS[text] == true)
    -- 繁/简汉字互斥：繁体模式丢掉简体汉字，简体模式丢掉繁体词典条目
    local han_now = looks_han(text)
    local skip = false
    if han_now then
      if trad_mode then
        if not from_trad then skip = true end
      else
        if from_trad then skip = true end
      end
    end
    -- 汉喃模式过滤：
    --   非模式 4：过滤掉含喃字的候选（from_nom）
    --   模式 4 且汉字模式（hanzi_mode=true）：过滤含拉丁候选，只留纯 CJK；
    --   hanzi_mode=false 时（Shift 切到英文拼写）不再过滤拉丁，正常出拉丁。
    if from_nom and not hannom_mode then skip = true end
    if hannom_mode and hanzi and has_quoc_ngu(text) then skip = true end
    if not skip and not end_overflow and (not from_qn or qn_mode) then
      local han = han_now
      local word = is_word(text)
      if hanzi then
        -- 汉字模式：汉字 + 国语字（拉丁）都显示
        if han then
          -- 汉字：按「候选字词 + 输入码」精确匹配注入带调越南语注释
          -- 繁体先用 TRAD_MAP 回查简体键（comment_map 是简体编的）
          local lookup = TRAD_MAP[text] or text
          -- 纯汉喃模式不含拉丁注释（hv_comment 忽略），只裸出汉字/喃字
          local m = (hv_comment and not hannom_mode) and COMMENTS[lookup:gsub("%s+", "")] or nil
          if m then
            local c = m[input_str]
            if not c then
              -- 简拼/混拼时输入码是缩写，查不到全拼 key；fallback 取默认读音（首个映射值）
              for _, v in pairs(m) do c = v; break end
            end
            if c then
              local g = cand:get_genuine()
              if g then
                g.comment = c
              end
            end
          end
          local out = (leading ~= "" and (leading .. text) or text)
          -- 繁体条目必须重建候选：原文带 ZWSP，直接 yield 会把不可见字符上屏
          if from_trad or leading ~= "" then
            yield(Candidate("trad", cand.start, cand._end, out, cand.comment or ""))
          else
            yield(cand)
          end
        else
          -- 拉丁（国语字）/ 标点：cap_mode 或自动大写时每音节首字母大写；
          -- 词加前导空格，标点不加。★ 之前漏了 cap（cap_mode），导致大写模式下
          -- 混合状态里的国语字候选不变大写。
          local out_text = text
          if cap or cap_auto then out_text = cap_syllables(text) end
          if word and leading ~= "" then
            yield(Candidate("leading", cand.start, cand._end, leading .. out_text, cand.comment or ""))
          elseif out_text ~= text then
            yield(Candidate("capitalized", cand.start, cand._end, out_text, cand.comment or ""))
          else
            yield(cand)
          end
        end
      else
        -- 国语字模式：只显示拉丁
        if not han then
          local out_text = text
          if cap or cap_auto then out_text = cap_syllables(text) end
          if word and leading ~= "" then
            yield(Candidate("leading", cand.start, cand._end, leading .. out_text, cand.comment or ""))
          elseif out_text ~= text then
            yield(Candidate("capitalized", cand.start, cand._end, out_text, cand.comment or ""))
          else
            yield(cand)
          end
        end
      end
    end
  end
end

return filter
